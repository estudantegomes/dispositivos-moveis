import React from 'react';
import { Button, View, Text, StyleSheet } from 'react-native';
import { Link, useRouter } from 'expo-router';

export default function HomeScreen() {
  const router = useRouter();

  return (
    <View style = {styles.container}>
      <Text style = {styles.title}>Início</Text>
      
      <Link href = "/about" style = {styles.link}>
        Ir para a Tela Sobre (com Link)
      </Link>
      
      <Link href = "/details/123" style={styles.link}>
        Ir para Detalhes ID 123 (com Link)
      </Link>

      <Button
          onPress={() => router.push("/details/10")}
          title="Ir para detalhes"
          color="#007BFF">
      </Button>
        
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 24, marginBottom: 20 },
  link: { color: 'blue', fontSize: 18, marginVertical: 10 },
});