import React from 'react';
import { Stack } from 'expo-router';

export default function StackLayout(){
    return (
        <Stack
        screenOptions={{
            headerStyle: { backgroundColor: "black" },
            headerTintColor: "#fff",
            headerTitleStyle: { fontWeight: "bold" },
        }}>

            <Stack.Screen name="index" options={{ title: 'Início' }} />
            <Stack.Screen name="about" options={{ title: 'Sobre' }} />
            
        </Stack>
    );
}