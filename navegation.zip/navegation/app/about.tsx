import { View, Text, StyleSheet } from 'react-native';
import { Link, useRouter } from 'expo-router';


export default function AboutScreen(){

    return(
        <View style = {styles.container}>
            <Text style = {styles.title}>Sobre</Text>

            <Text style = {styles.paragraph}>Linguistique est **lorem ipsum** in natura. **Dolor sit amet**, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, **quis nostrud exercitation** ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. **Excepteur sint** occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</Text>

            <Link href = "/" style = {styles.link}>
                    Ir para a Tela Home (com Link)
            </Link>

        </View>
    );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 24, marginBottom: 20 },
  paragraph: {fontSize: 15, margin: 20, textAlign: 'justify'},
  link: { color: 'blue', fontSize: 18, marginVertical: 10 },
});