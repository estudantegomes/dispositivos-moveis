import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';

export default function DetailsScreen() {
  const params = useLocalSearchParams();

  return (
    <View style={styles.container}>

      <Stack.Screen options={{ title: `Detalhes do Item ${params.id}` }} />
      
      <Text style={styles.title}>
        Detalhes do Item
      </Text>

      <Text style={styles.text}>
        Parâmetro recebido (ID): {params.id}
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#e0f7fa' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  text: { fontSize: 18, color: '#333' },
});
